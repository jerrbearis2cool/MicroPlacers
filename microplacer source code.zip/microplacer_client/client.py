import json

import pygame, random, requests, time
resx, resy = 100, 100
x, y = 1000, 800
display = {(0,0):(0, 0, 0)}
screen = pygame.display.set_mode([x, y])
pygame.display.set_caption("microplacers")
title = pygame.image.load('assets\\title.png')
cursor = pygame.image.load('assets\\crosshair.png')
cursor_white = pygame.image.load('assets\\crosshair_white.png')
colors = pygame.image.load('assets\\colours.png')
title = pygame.transform.scale(title, (180, 40))
colors = pygame.transform.scale(colors, (150, 350))
description = pygame.image.load('assets\\description.png')
description = pygame.transform.scale(description, (180, 90))
pygame.mouse.set_visible(0)

RED = (255, 0, 0)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREY = (200, 200, 200)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
PURPLE = (130, 0, 130)
YELLOW = (255, 255, 0)
color = (0, 0, 0, 0)

def put(x, y, r, g, b):
    display[(x, y)] = (r, g, b)

running = True
data = {}
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    screen.fill((255, 255, 255))
    try:
        data = requests.get("http://68.147.7.113:3334/?placerData=wutever").json()
    except json.decoder.JSONDecodeError:
        pass
    pygame.event.get()
    for a in range(0, resy):
        for z in range(0, resx):
            if (str(a) + "," + str(z)) not in data:
                pygame.draw.rect(screen, (255, 255, 255), (z * 8, a * 8, 8, 8))
            elif (str(a) + "," + str(z)) in data:
                try:
                    pixel = str(a) + "," + str(z)
                    r, g, b = 0, 0, 0
                    r, g, b = int(data[pixel].get("r")), int(data[pixel].get("g")), int(data[pixel].get("b"))
                    pygame.draw.rect(screen, (r, g, b), (z * 8, a * 8, 8, 8))
                except KeyError:
                    pass
    mouse_x, mouse_y = pygame.mouse.get_pos()
    place_y, place_x = int((mouse_x / 8) + 1), int((mouse_y / 8) + 1)
    sidebar = pygame.draw.rect(screen, (0, 0, 0), (800, 0, 800, 800))
    mouse_collide = pygame.draw.rect(screen, (0, 0, 0), (mouse_x + 7, mouse_y + 7, 1, 1))
    screen.blit(title, (810, 10))
    screen.blit(colors, (825, 100))
    screen.blit(description, (810, 500))
    if sidebar.colliderect(mouse_collide):
        screen.blit(cursor_white, (mouse_x, mouse_y))
    else:
        screen.blit(cursor, (mouse_x, mouse_y))
    l_click, m_click, r_click = pygame.mouse.get_pressed()
    if r_click == True:
        color = screen.get_at(pygame.mouse.get_pos())
    if l_click == True:
        r, g, b, extra = color
        requests.get("http://68.147.7.113:3334/?rgb="+str(r)+","+str(g)+","+str(b)+"&coords="+str(place_x)+","+str(place_y))
        print("http://68.147.7.113:3334/?rgb="+str(r)+","+str(g)+","+str(b)+"&coords="+str(int(place_x))+","+str(int(place_y)))
        print(place_x, place_y)
        print(r,g,b)
    pygame.display.update()
